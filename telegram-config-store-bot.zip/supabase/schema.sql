create extension if not exists pgcrypto;

create table if not exists users (
  telegram_id bigint primary key,
  username text,
  first_name text,
  balance_toman bigint not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists user_states (
  user_id bigint primary key,
  step text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
-- The function code stores wizard fields in data. Generated columns are avoided for portability.
alter table user_states add column if not exists amount_toman bigint;
alter table user_states add column if not exists plan_id uuid;
alter table user_states add column if not exists draft_name text;
alter table user_states add column if not exists draft_volume numeric;
alter table user_states add column if not exists draft_days integer;
alter table user_states add column if not exists draft_price bigint;
alter table user_states add column if not exists draft_label text;
alter table user_states add column if not exists draft_kind text;

create table if not exists plans (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  volume_gb numeric not null,
  duration_days integer not null,
  price_toman bigint not null,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists stock (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid not null references plans(id),
  config_text text not null,
  status text not null default 'available' check(status in ('available','sold','disabled')),
  sold_to bigint references users(telegram_id),
  sold_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references users(telegram_id),
  plan_id uuid not null references plans(id),
  stock_id uuid not null references stock(id),
  price_toman bigint not null,
  created_at timestamptz not null default now()
);
create table if not exists deposits (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references users(telegram_id),
  amount_toman bigint not null check(amount_toman > 0),
  receipt_file_id text not null,
  status text not null default 'pending' check(status in ('pending','approved','rejected')),
  reviewed_by bigint,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists custom_buttons (
  id uuid primary key default gen_random_uuid(),
  label text not null,
  kind text not null check(kind in ('text','url','plans','support')),
  payload text,
  active boolean not null default true,
  sort_order integer not null default 0
);
create table if not exists settings (
  id integer primary key default 1 check(id=1),
  payment_text text,
  support_text text
);
insert into settings(id,payment_text,support_text) values(1,'شماره کارت را مدیر تنظیم می‌کند.','برای پشتیبانی با مدیر تماس بگیرید.')
on conflict(id) do nothing;

create or replace function purchase_stock(p_telegram_id bigint, p_plan_id uuid)
returns table(config_text text, plan_name text)
language plpgsql security definer as $$
declare u users%rowtype; p plans%rowtype; s stock%rowtype;
begin
  select * into u from users where telegram_id=p_telegram_id for update;
  select * into p from plans where id=p_plan_id and active=true;
  if u.telegram_id is null or p.id is null then return; end if;
  if u.balance_toman < p.price_toman then return; end if;
  select * into s from stock where plan_id=p_plan_id and status='available' order by created_at for update skip locked limit 1;
  if s.id is null then return; end if;
  update users set balance_toman=balance_toman-p.price_toman where telegram_id=p_telegram_id;
  update stock set status='sold', sold_to=p_telegram_id, sold_at=now() where id=s.id;
  insert into orders(telegram_id,plan_id,stock_id,price_toman) values(p_telegram_id,p.id,s.id,p.price_toman);
  return query select s.config_text,p.name;
end $$;

create or replace function approve_deposit(p_deposit_id uuid,p_admin_id bigint)
returns json language plpgsql security definer as $$
declare d deposits%rowtype;
begin
  select * into d from deposits where id=p_deposit_id for update;
  if d.id is null or d.status <> 'pending' then return json_build_object('ok',false); end if;
  update deposits set status='approved',reviewed_by=p_admin_id,reviewed_at=now() where id=d.id;
  update users set balance_toman=balance_toman+d.amount_toman where telegram_id=d.telegram_id;
  return json_build_object('ok',true,'telegram_id',d.telegram_id);
end $$;

create or replace function reject_deposit(p_deposit_id uuid,p_admin_id bigint)
returns json language plpgsql security definer as $$
declare d deposits%rowtype;
begin
  select * into d from deposits where id=p_deposit_id for update;
  if d.id is null or d.status <> 'pending' then return json_build_object('ok',false); end if;
  update deposits set status='rejected',reviewed_by=p_admin_id,reviewed_at=now() where id=d.id;
  return json_build_object('ok',true,'telegram_id',d.telegram_id);
end $$;

-- Keep user balance protected from direct public writes. Use service-role credentials only in the function.
alter table users enable row level security;
alter table plans enable row level security;
alter table stock enable row level security;
alter table deposits enable row level security;
alter table orders enable row level security;
alter table custom_buttons enable row level security;
alter table settings enable row level security;
alter table user_states enable row level security;
